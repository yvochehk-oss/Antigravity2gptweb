from sqlalchemy import String,Float,ForeignKey,Boolean
from sqlalchemy.orm import Mapped,mapped_column
from .db import Base
class Entity(Base):
 __tablename__="entities"; id:Mapped[int]=mapped_column(primary_key=True); code:Mapped[str]=mapped_column(String(8),unique=True); name:Mapped[str]=mapped_column(String(100)); kind:Mapped[str]=mapped_column(String(30)); internal:Mapped[bool]=mapped_column(Boolean)
class Project(Base):
 __tablename__="projects"; id:Mapped[int]=mapped_column(primary_key=True); code:Mapped[str]=mapped_column(String(30),unique=True); name:Mapped[str]=mapped_column(String(120)); city:Mapped[str]=mapped_column(String(40)); contract_total:Mapped[float]=mapped_column(Float); tax_method:Mapped[str]=mapped_column(String(20))
class RealCost(Base):
 __tablename__="real_costs"; id:Mapped[int]=mapped_column(primary_key=True); project_id:Mapped[int]=mapped_column(ForeignKey("projects.id")); entity_code:Mapped[str]=mapped_column(String(8)); category:Mapped[str]=mapped_column(String(30)); amount:Mapped[float]=mapped_column(Float); external_cash:Mapped[bool]=mapped_column(Boolean); note:Mapped[str]=mapped_column(String(200),default="")
class Progress(Base):
 __tablename__="progress"; id:Mapped[int]=mapped_column(primary_key=True); project_id:Mapped[int]=mapped_column(ForeignKey("projects.id")); period:Mapped[str]=mapped_column(String(7)); output_value:Mapped[float]=mapped_column(Float); settlement:Mapped[float]=mapped_column(Float); recognized_revenue:Mapped[float]=mapped_column(Float); collection:Mapped[float]=mapped_column(Float)
class Invoice(Base):
 __tablename__="invoices"; id:Mapped[int]=mapped_column(primary_key=True); project_id:Mapped[int]=mapped_column(ForeignKey("projects.id")); entity_code:Mapped[str]=mapped_column(String(8)); direction:Mapped[str]=mapped_column(String(10)); counterparty_code:Mapped[str]=mapped_column(String(8)); category:Mapped[str]=mapped_column(String(30)); net:Mapped[float]=mapped_column(Float); vat:Mapped[float]=mapped_column(Float); deductible:Mapped[bool]=mapped_column(Boolean)
