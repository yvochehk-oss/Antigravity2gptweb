from .db import Base,engine,SessionLocal
from .models import *
def run():
 Base.metadata.create_all(engine); db=SessionLocal()
 if db.query(Entity).count(): db.close(); return
 rows=[("A","施工企业A","construction",1),("B","劳务公司B","labor",1),("C","商贸公司C","trade",1),("D","设备租赁公司D","equipment",1),("甲","第三方劳务公司甲","labor",0),("乙","第三方设备租赁公司乙","equipment",0),("丙","外部材料供应商丙","material",0),("丁","外部专业分包/其他供应商丁","subcontract",0)]
 for c,n,k,i in rows: db.add(Entity(code=c,name=n,kind=k,internal=bool(i)))
 p=Project(code="YB-DEMO-001",name="宜宾示范工业项目",city="宜宾",contract_total=100000000,tax_method="general"); db.add(p); db.flush(); db.add(Progress(project_id=p.id,period="2026-08",output_value=25000000,settlement=22000000,recognized_revenue=23000000,collection=18000000))
 for c,k,a,n in [("A","project_management",1200000,"A项目部真实成本"),("B","labor",5600000,"B工资社保真实成本"),("C","material",8500000,"C材料外采真实成本"),("D","equipment",1600000,"D设备运营真实成本"),("甲","labor",1100000,"第三方劳务外部成本")]: db.add(RealCost(project_id=p.id,entity_code=c,category=k,amount=a,external_cash=c not in {"A","B","C","D"},note=n))
 db.add_all([Invoice(project_id=p.id,entity_code="A",direction="out",counterparty_code="业主",category="construction",net=23000000,vat=2070000,deductible=False),Invoice(project_id=p.id,entity_code="A",direction="in",counterparty_code="丙",category="material",net=4000000,vat=520000,deductible=True)]); db.commit(); db.close()
if __name__=="__main__": run()
