from sqlalchemy import select,func
from .models import *
def project_summary(db,pid):
 p=db.get(Project,pid); revenue=db.scalar(select(func.coalesce(func.sum(Progress.recognized_revenue),0)).where(Progress.project_id==pid)) or 0; costs=db.execute(select(RealCost).where(RealCost.project_id==pid)).scalars().all(); real=sum(x.amount for x in costs); inv=db.execute(select(Invoice).where(Invoice.project_id==pid)).scalars().all(); outvat=sum(x.vat for x in inv if x.direction=="out"); invat=sum(x.vat for x in inv if x.direction=="in" and x.deductible); profit=revenue-real; prog=revenue/p.contract_total if p.contract_total else 0; eac=max(real/prog if prog>.05 else real,real); return {"project":p,"revenue":revenue,"real_cost":real,"profit":profit,"vat":max(outvat-invat,0),"eac":eac,"eac_profit":p.contract_total-eac}
def consolidated(db):
 ps=db.execute(select(Project)).scalars().all(); rows=[project_summary(db,p.id) for p in ps]; return {"rows":rows,"revenue":sum(x["revenue"] for x in rows),"cost":sum(x["real_cost"] for x in rows),"profit":sum(x["profit"] for x in rows),"vat":sum(x["vat"] for x in rows)}
