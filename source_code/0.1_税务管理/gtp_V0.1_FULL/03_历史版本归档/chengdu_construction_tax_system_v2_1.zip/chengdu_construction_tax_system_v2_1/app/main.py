from fastapi import FastAPI,Request,Form
from fastapi.responses import HTMLResponse,RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from .db import SessionLocal
from .models import Entity,Project,RealCost,Contract,CashFlow,Fulfillment,Budget
from .engine import consolidated,project_summary
app=FastAPI(title="建筑项目经营与税务统筹系统",version="2.0")
t=Jinja2Templates(directory="app/templates")
@app.get("/",response_class=HTMLResponse)
def home(r:Request):
 db=SessionLocal(); d=consolidated(db); db.close(); return t.TemplateResponse("home.html",{"request":r,"d":d})
@app.get("/project/{pid}",response_class=HTMLResponse)
def project(r:Request,pid:int):
 db=SessionLocal(); s=project_summary(db,pid); costs=db.execute(select(RealCost).where(RealCost.project_id==pid)).scalars().all(); db.close(); return t.TemplateResponse("project.html",{"request":r,"s":s,"costs":costs})
@app.get("/manage",response_class=HTMLResponse)
def manage(r:Request):
 db=SessionLocal(); ps=db.execute(select(Project)).scalars().all(); es=db.execute(select(Entity)).scalars().all(); db.close(); return t.TemplateResponse("manage.html",{"request":r,"projects":ps,"entities":es})
@app.post("/manage/cost")
def add_cost(project_id:int=Form(...),entity_code:str=Form(...),category:str=Form(...),amount:float=Form(...),note:str=Form("")):
 db=SessionLocal(); db.add(RealCost(project_id=project_id,entity_code=entity_code,category=category,amount=amount,external_cash=entity_code not in {"A","B","C","D"},note=note)); db.commit(); db.close(); return RedirectResponse(f"/project/{project_id}",303)

@app.post("/manage/contract")
def add_contract(project_id:int=Form(...),buyer_code:str=Form(...),seller_code:str=Form(...),category:str=Form(...),amount:float=Form(...),note:str=Form("")):
 db=SessionLocal(); db.add(Contract(project_id=project_id,buyer_code=buyer_code,seller_code=seller_code,category=category,amount=amount,internal_trade=buyer_code in {"A","B","C","D"} and seller_code in {"A","B","C","D"},note=note)); db.commit(); db.close(); return RedirectResponse("/manage",303)
@app.post("/manage/cashflow")
def add_cashflow(project_id:int=Form(...),entity_code:str=Form(...),counterparty_code:str=Form(...),direction:str=Form(...),amount:float=Form(...),period:str=Form(...),note:str=Form("")):
 db=SessionLocal(); db.add(CashFlow(project_id=project_id,entity_code=entity_code,counterparty_code=counterparty_code,direction=direction,amount=amount,period=period,note=note)); db.commit(); db.close(); return RedirectResponse("/manage",303)
@app.post("/manage/fulfillment")
def add_fulfillment(project_id:int=Form(...),counterparty_code:str=Form(...),kind:str=Form(...),quantity:float=Form(0),amount:float=Form(0),evidence_complete:bool=Form(False),note:str=Form("")):
 db=SessionLocal(); db.add(Fulfillment(project_id=project_id,counterparty_code=counterparty_code,kind=kind,quantity=quantity,amount=amount,evidence_complete=evidence_complete,note=note)); db.commit(); db.close(); return RedirectResponse("/manage",303)
