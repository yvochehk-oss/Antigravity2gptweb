import csv, io, json
from fastapi import FastAPI,Request,Form,UploadFile,File
from fastapi.responses import HTMLResponse,RedirectResponse,JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from .db import SessionLocal, Base, engine
from .models import *
from .engine import consolidated,project_summary,matching_rows,rebuild_tax_ledger,scan_risks,cost_tree_summary
from .ai_review import SCOPES, run_review

app=FastAPI(title="建筑项目经营与税务统筹系统",version="2.3")
t=Jinja2Templates(directory="app/templates")

def audit(db,action,obj,obj_id,msg):
    db.add(AuditLog(action=action,object_type=obj,object_id=str(obj_id),message=msg))

@app.get("/",response_class=HTMLResponse)
def home(r:Request):
    db=SessionLocal(); d=consolidated(db); risks=db.execute(select(RiskEvent).where(RiskEvent.resolved==False)).scalars().all()
    db.close(); return t.TemplateResponse("home.html",{"request":r,"d":d,"risk_count":len(risks)})

@app.get("/project/{pid}",response_class=HTMLResponse)
def project(r:Request,pid:int):
    db=SessionLocal(); s=project_summary(db,pid)
    costs=db.execute(select(RealCost).where(RealCost.project_id==pid)).scalars().all()
    tree=cost_tree_summary(db,pid); db.close()
    return t.TemplateResponse("project.html",{"request":r,"s":s,"costs":costs,"tree":tree})

@app.get("/manage",response_class=HTMLResponse)
def manage(r:Request):
    db=SessionLocal()
    ps=db.execute(select(Project)).scalars().all(); es=db.execute(select(Entity)).scalars().all()
    db.close(); return t.TemplateResponse("manage.html",{"request":r,"projects":ps,"entities":es})

@app.post("/manage/cost")
def add_cost(project_id:int=Form(...),entity_code:str=Form(...),counterparty_code:str=Form(""),category:str=Form(...),subcategory:str=Form(""),
             period:str=Form("2026-08"),amount:float=Form(...),external_cash:bool=Form(False),note:str=Form("")):
    db=SessionLocal(); x=RealCost(project_id=project_id,entity_code=entity_code,counterparty_code=counterparty_code,
        category=category,subcategory=subcategory,period=period,amount=amount,external_cash=external_cash,note=note)
    db.add(x); db.flush(); audit(db,"CREATE","RealCost",x.id,f"{entity_code}/{category}/{amount}"); db.commit(); db.close()
    return RedirectResponse(f"/project/{project_id}",303)

@app.post("/manage/contract")
def add_contract(project_id:int=Form(...),contract_no:str=Form(""),buyer_code:str=Form(...),seller_code:str=Form(...),
                 category:str=Form(...),amount:float=Form(...),note:str=Form("")):
    db=SessionLocal(); x=Contract(project_id=project_id,contract_no=contract_no,buyer_code=buyer_code,seller_code=seller_code,
        category=category,amount=amount,internal_trade=buyer_code in {"A","B","C","D"} and seller_code in {"A","B","C","D"},note=note)
    db.add(x); db.flush(); audit(db,"CREATE","Contract",x.id,f"{contract_no}/{seller_code}/{amount}"); db.commit(); db.close()
    return RedirectResponse("/manage",303)

@app.post("/manage/invoice")
def add_invoice(project_id:int=Form(...),invoice_no:str=Form(""),period:str=Form(...),entity_code:str=Form(...),
                direction:str=Form(...),counterparty_code:str=Form(...),category:str=Form(...),net:float=Form(...),
                vat:float=Form(0),rate:float=Form(0),deductible:bool=Form(False),note:str=Form("")):
    db=SessionLocal(); x=Invoice(project_id=project_id,invoice_no=invoice_no,period=period,entity_code=entity_code,
        direction=direction,counterparty_code=counterparty_code,category=category,net=net,vat=vat,rate=rate,
        deductible=deductible,note=note)
    db.add(x); db.flush(); audit(db,"CREATE","Invoice",x.id,f"{invoice_no}/{direction}/{net+vat}"); db.commit(); db.close()
    return RedirectResponse("/manage",303)

@app.post("/manage/cashflow")
def add_cashflow(project_id:int=Form(...),entity_code:str=Form(...),counterparty_code:str=Form(...),direction:str=Form(...),
                 amount:float=Form(...),period:str=Form(...),note:str=Form("")):
    db=SessionLocal(); x=CashFlow(project_id=project_id,entity_code=entity_code,counterparty_code=counterparty_code,
        direction=direction,amount=amount,period=period,note=note)
    db.add(x); db.flush(); audit(db,"CREATE","CashFlow",x.id,f"{counterparty_code}/{direction}/{amount}"); db.commit(); db.close()
    return RedirectResponse("/manage",303)

@app.post("/manage/fulfillment")
def add_fulfillment(project_id:int=Form(...),counterparty_code:str=Form(...),kind:str=Form(...),category:str=Form(...),
                    quantity:float=Form(0),amount:float=Form(0),evidence_complete:bool=Form(False),note:str=Form("")):
    db=SessionLocal(); x=Fulfillment(project_id=project_id,counterparty_code=counterparty_code,kind=kind,category=category,
        quantity=quantity,amount=amount,evidence_complete=evidence_complete,note=note)
    db.add(x); db.flush(); audit(db,"CREATE","Fulfillment",x.id,f"{counterparty_code}/{kind}/{amount}"); db.commit(); db.close()
    return RedirectResponse("/manage",303)

@app.get("/matching",response_class=HTMLResponse)
def matching(r:Request,project_id:int|None=None):
    db=SessionLocal(); ps=db.execute(select(Project)).scalars().all()
    pid=project_id or (ps[0].id if ps else None); rows=matching_rows(db,pid) if pid else []
    db.close(); return t.TemplateResponse("matching.html",{"request":r,"projects":ps,"pid":pid,"rows":rows})

@app.get("/tax-ledger",response_class=HTMLResponse)
def tax_ledger(r:Request,period:str="2026-08"):
    db=SessionLocal(); rows=rebuild_tax_ledger(db,period)
    unreviewed=db.execute(select(TaxRule).where(TaxRule.reviewed==False)).scalars().all()
    db.close(); return t.TemplateResponse("tax_ledger.html",{"request":r,"rows":rows,"period":period,"unreviewed":len(unreviewed)})

@app.get("/risks",response_class=HTMLResponse)
def risks(r:Request,project_id:int|None=None):
    db=SessionLocal(); ps=db.execute(select(Project)).scalars().all()
    pid=project_id or (ps[0].id if ps else None); rows=scan_risks(db,pid) if pid else []
    db.close(); return t.TemplateResponse("risks.html",{"request":r,"projects":ps,"pid":pid,"rows":rows})

@app.get("/audit",response_class=HTMLResponse)
def audits(r:Request):
    db=SessionLocal(); rows=db.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(200)).scalars().all()
    db.close(); return t.TemplateResponse("audit.html",{"request":r,"rows":rows})

@app.get("/imports",response_class=HTMLResponse)
def imports(r:Request):
    db=SessionLocal(); ps=db.execute(select(Project)).scalars().all(); db.close()
    return t.TemplateResponse("imports.html",{"request":r,"projects":ps,"message":""})

@app.post("/imports/invoices",response_class=HTMLResponse)
async def import_invoices(r:Request,project_id:int=Form(...),file:UploadFile=File(...)):
    raw=(await file.read()).decode("utf-8-sig"); reader=csv.DictReader(io.StringIO(raw)); db=SessionLocal(); ok=0; errors=[]
    for n,row in enumerate(reader,2):
        try:
            x=Invoice(project_id=project_id,invoice_no=row.get("invoice_no",""),period=row["period"],entity_code=row["entity_code"],
                direction=row["direction"],counterparty_code=row["counterparty_code"],category=row["category"],
                net=float(row["net"]),vat=float(row.get("vat") or 0),rate=float(row.get("rate") or 0),
                deductible=str(row.get("deductible","1")).lower() in ("1","true","yes","y"),note=row.get("note",""))
            db.add(x); ok+=1
        except Exception as e: errors.append(f"第{n}行: {e}")
    audit(db,"IMPORT","Invoice",project_id,f"{file.filename}: 成功{ok}行，失败{len(errors)}行"); db.commit()
    ps=db.execute(select(Project)).scalars().all(); db.close()
    msg=f"发票导入完成：成功 {ok} 行，失败 {len(errors)} 行。" + (" | "+"; ".join(errors[:5]) if errors else "")
    return t.TemplateResponse("imports.html",{"request":r,"projects":ps,"message":msg})

@app.post("/imports/cashflows",response_class=HTMLResponse)
async def import_cashflows(r:Request,project_id:int=Form(...),file:UploadFile=File(...)):
    raw=(await file.read()).decode("utf-8-sig"); reader=csv.DictReader(io.StringIO(raw)); db=SessionLocal(); ok=0; errors=[]
    for n,row in enumerate(reader,2):
        try:
            db.add(CashFlow(project_id=project_id,entity_code=row["entity_code"],counterparty_code=row["counterparty_code"],
                direction=row["direction"],amount=float(row["amount"]),period=row["period"],note=row.get("note",""))); ok+=1
        except Exception as e: errors.append(f"第{n}行: {e}")
    audit(db,"IMPORT","CashFlow",project_id,f"{file.filename}: 成功{ok}行，失败{len(errors)}行"); db.commit()
    ps=db.execute(select(Project)).scalars().all(); db.close()
    msg=f"流水导入完成：成功 {ok} 行，失败 {len(errors)} 行。" + (" | "+"; ".join(errors[:5]) if errors else "")
    return t.TemplateResponse("imports.html",{"request":r,"projects":ps,"message":msg})

@app.get("/api/projects/{pid}")
def api_project(pid:int):
    db=SessionLocal(); s=project_summary(db,pid)
    out={k:v for k,v in s.items() if k!="project"}; out["project"]={"id":s["project"].id,"code":s["project"].code,"name":s["project"].name}
    db.close(); return out

@app.get("/api/projects/{pid}/matching")
def api_matching(pid:int):
    db=SessionLocal(); rows=matching_rows(db,pid); db.close(); return rows


@app.get("/ai-review",response_class=HTMLResponse)
def ai_review_home(r:Request,project_id:int|None=None,scope:str|None=None):
    db=SessionLocal()
    projects=db.execute(select(Project)).scalars().all()
    endpoints=db.execute(select(AIModelEndpoint).where(AIModelEndpoint.enabled==True).order_by(AIModelEndpoint.id)).scalars().all()
    jobs=db.execute(select(AIReviewJob).order_by(AIReviewJob.id.desc()).limit(50)).scalars().all()
    project_map={p.id:p for p in projects}; endpoint_map={e.id:e for e in db.execute(select(AIModelEndpoint)).scalars().all()}
    db.close()
    return t.TemplateResponse("ai_review.html",{"request":r,"projects":projects,"endpoints":endpoints,"jobs":jobs,
        "project_map":project_map,"endpoint_map":endpoint_map,"scopes":SCOPES,"selected_project_id":project_id,"selected_scope":scope})

@app.post("/ai-review/run")
def ai_review_run(project_id:int=Form(...),scope:str=Form(...),endpoint_id:int=Form(...),user_instruction:str=Form("")):
    db=SessionLocal()
    if scope not in SCOPES:
        db.close(); return RedirectResponse("/ai-review",303)
    job=AIReviewJob(project_id=project_id,scope=scope,endpoint_id=endpoint_id,user_instruction=user_instruction,
                    status="pending",created_at=__import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(timespec="seconds"))
    db.add(job); db.flush(); audit(db,"AI_REVIEW_START","AIReviewJob",job.id,f"project={project_id}, scope={scope}, endpoint={endpoint_id}")
    db.commit()
    try:
        run_review(db,job)
        audit(db,"AI_REVIEW_COMPLETE","AIReviewJob",job.id,f"status={job.status}")
        db.commit()
    except Exception as e:
        audit(db,"AI_REVIEW_FAILED","AIReviewJob",job.id,str(e))
        db.commit()
    jid=job.id; db.close()
    return RedirectResponse(f"/ai-review/{jid}",303)

@app.get("/ai-review/{job_id}",response_class=HTMLResponse)
def ai_review_detail(r:Request,job_id:int):
    db=SessionLocal()
    job=db.get(AIReviewJob,job_id)
    if not job:
        db.close(); return HTMLResponse("AI review job not found",404)
    project=db.get(Project,job.project_id); endpoint=db.get(AIModelEndpoint,job.endpoint_id)
    result=db.scalar(select(AIReviewResult).where(AIReviewResult.job_id==job.id))
    findings=[]; recommendations=[]; gaps=[]
    if result:
        try: findings=json.loads(result.findings_json or "[]")
        except: findings=[]
        try: recommendations=json.loads(result.recommendations_json or "[]")
        except: recommendations=[]
        try: gaps=json.loads(result.data_gaps_json or "[]")
        except: gaps=[]
    db.close()
    return t.TemplateResponse("ai_review_detail.html",{"request":r,"job":job,"project":project,"endpoint":endpoint,
        "result":result,"findings":findings,"recommendations":recommendations,"gaps":gaps,"scope_name":SCOPES.get(job.scope,job.scope)})

@app.get("/ai-models",response_class=HTMLResponse)
def ai_models(r:Request):
    db=SessionLocal(); rows=db.execute(select(AIModelEndpoint).order_by(AIModelEndpoint.id)).scalars().all(); db.close()
    return t.TemplateResponse("ai_models.html",{"request":r,"rows":rows})

@app.post("/ai-models")
def ai_model_add(name:str=Form(...),adapter:str=Form("openai_compatible"),base_url:str=Form(""),
                 chat_path:str=Form("/v1/chat/completions"),model:str=Form(""),api_key_env:str=Form(""),
                 timeout_seconds:int=Form(90),note:str=Form("")):
    db=SessionLocal()
    x=AIModelEndpoint(name=name,adapter=adapter,base_url=base_url,chat_path=chat_path,model=model,
                      api_key_env=api_key_env,enabled=True,timeout_seconds=timeout_seconds,note=note)
    db.add(x); db.flush(); audit(db,"CREATE","AIModelEndpoint",x.id,f"{name}/{adapter}/{model}"); db.commit(); db.close()
    return RedirectResponse("/ai-models",303)

@app.post("/ai-models/{endpoint_id}/toggle")
def ai_model_toggle(endpoint_id:int):
    db=SessionLocal(); x=db.get(AIModelEndpoint,endpoint_id)
    if x:
        x.enabled=not x.enabled; audit(db,"UPDATE","AIModelEndpoint",x.id,f"enabled={x.enabled}"); db.commit()
    db.close(); return RedirectResponse("/ai-models",303)

@app.get("/api/ai-review/{job_id}")
def api_ai_review(job_id:int):
    db=SessionLocal(); job=db.get(AIReviewJob,job_id)
    if not job:
        db.close(); return JSONResponse({"error":"not found"},404)
    result=db.scalar(select(AIReviewResult).where(AIReviewResult.job_id==job.id))
    out={"job":{"id":job.id,"project_id":job.project_id,"scope":job.scope,"status":job.status,
                "created_at":job.created_at,"started_at":job.started_at,"finished_at":job.finished_at,
                "input_digest":job.input_digest,"error_message":job.error_message}}
    if result:
        out["result"]={"risk_level":result.risk_level,"score":result.score,"summary":result.summary,
                       "findings":json.loads(result.findings_json or "[]"),
                       "recommendations":json.loads(result.recommendations_json or "[]"),
                       "data_gaps":json.loads(result.data_gaps_json or "[]"),
                       "provider_name":result.provider_name,"model_name":result.model_name}
    db.close(); return out
